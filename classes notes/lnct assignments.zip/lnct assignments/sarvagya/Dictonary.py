# a = ["hello",2.3,4,7,'234',9]
# print (len(a))

# a = ["hello",2.3,4,7,'234',9]
# print (a[-1])

# a = ["hello",2.3,4,7,'234',9]
# print (a[1:6])

# lis = ["apple", "mango", "banana","pineapple"]
# lis.append("orange")
# lis[2]=",ms"
# lis[3:5]=(",ms","equ")

# lis.insert(1,"hsg")
# print(lis)
# def sam(name):
#     nme = input("enter your name : ")
#     return nme
# sn = sam(name=sam)
# print (f"hi this"{sn})

# import math 

# hb = [1,2,5,6,7,340,90]
# de= [2,3,44,413,41]
# # de.extend(hb)    
# print(hb)

# lis = ["kb", "mango", "banana","apple","pineapple"]
# lis.remove("mango") #to remove the character 
# lis.pop(0)# to remove with index 
# del lis[1]# same as pop
# lis.clear()#clear list 
# lis.sort()
# lis.sort(reverse=True)
# print(lis)


# a = [1,2,4,5,543,34]
# for a[i] in range(1,34,5):
#     print(i)
