# lst = ["hello","my","name","is","sarvagya" ]
# lst2 = "bho bah tha , bac mer tha  " 
# print(lst2)
# print(lst2.split("a"))
# # print(lst)
# print("-".join(lst))

# board = [[" ", " ", " "],[ " ", " ", " "],[ " ", " "," "]]

# for i in range(3):
#     print("|".join(board[i]))
#     print("-"*6)

# x= 1
# y=1
# z=2
# n=2
# list = []
# for i in range(x+1):
#     for j in range(y+1):
#         for  k in range(z+1):
#             if sum((i,j,k))!= n:
#                 list.append((i,j,k))
#             else:
#                 print(list)
# N = int(input())
# lis=[]
# for i in range(N):
#     num = float(input(f"Input number {i+1}: "))
#     lis.append(num)
# =================================================================


# N = int(input())
# numbers = []
# for i in range(N+1):
#     com = input()
#     temp1=com.split(" ")
#     if temp1[0]== "insert":
#         numbers.insert(int(temp1[1]),int(temp1[2]))
#         print(numbers)
#     elif temp1[0]== "list":
#         numbers.list()
#         print(numbers)
#     elif temp1[0]== "append":
#         numbers.append(int(temp1[1]))
#         print(numbers)
#     elif temp1[0]== "extend":
#         numbers.extend(int(temp1[1]),int(temp1[2]))
#         print(numbers)
#     elif temp1[0]== "remove":
#         numbers.remove(int(temp1[1]))
#         print(numbers)
#     elif temp1[0]== "pop":
#         numbers.pop()
#         print(numbers)
#     elif temp1[0]== "sort":
#         numbers.sort()
#         print(numbers)
#     elif temp1[0]== "reverse":
#         numbers.reverse()
#         print(numbers)
#     else:
#         print("Invalid command")
        
# =================================================================
    
# com = input()
# print()
# temp=com.split(" ")
# print (com)
# print(temp)
# print(temp[0],temp[1])

# =================================================================
# D ={}
# D["name"] = "sarvagya"
# D["ROLE no"] = 10
# D["name"] = "sam"
# D["ROLE no"] = 4

# print(D)

# for i in D:
#     print(f" {i}==========->{D[i]}")

# =================================================================
# list = []
# for i in range(0, 10 ,2):
#     list.append(i)
# print(list)
 
# # add number to the maximum number

# t =(2,4,5,10)
# num = int(input("enter the number :"))
# print(t+((t[t.index(10)])+num,))

# # add number to the minimum number

# t =(2,4,5,10)
# for i in t:
#     print(i)
# temp = list(t)
# num = temp.index(min(temp))
# temp[num]= temp[num] + int(input("enter the number : "))
# t = tuple(temp)

# print(t)

# # =================================================================

# student ={}

# student["Name"]=["a","b","c","d","e"]
# student["Roll"]=[1,2,3,4,5,6]

# student["Name"].append("f")
# student["Roll"].append(7)
# for i in student:
#    print(f" {i}==========->{student[i]}")



# print(student)
# =================================================================

# d ={}
# for i in range(3):
#     temp =[]
#     k = input("enter the name :  ")
#     # temp.append(input("enter the element :"))
#     for j in range(4):
#         temp.append(int(input(f"enter the element of {k} : ")))
#         # temp[1].append(input(f"enter the element of {k} : "))
#         d[k] = temp
#     print(d)
        

# =================================================================

# d= {}
# for i in range(2):
#     temp=[]
#     f = input("enter the class name  : ")
#     for j in range(1):
#         temp.append(input(f"enter the marks of student {j+1} in {f} : "))
#         d[f]= temp
#     print(d)
        

# =================================================================

# d = {"brand": "Nike", "product": "Shoes"}
# v = {"gam": "hd", "ghd": "Sho"}

# ans= d.update(v)
# print(ans)

# d.update({"color": "same"})

# d.pop("product")

# print(d)


# =================================================================
# g= input("")
# temp = g.split(" ")
# ge={ }

# for i in temp:
#     ge[i]=temp.count(i)
# print(ge)

# =================================================================
# m = {}
# g = input(" what is the name of key ")
# gam= input(" what is the key ")
# m[g]=gam
# check =input("check : ")
# if check in m:
#     print("key exists")
# else:
#     print("key missing ")

# =================================================================

# m = {"a": 1, "b": 2, "c": 3, "d":4}
# temp = input(" what is the name of key ")
# print(m[temp])
# print(m.keys())

# g = {"a": 1, "b": 2, "c": 3, "d":4}
# print(g.values())

# h = {"g": 1, "r": 2, "c": 3, "s":4}
# h= dict(sorted(h.items()))
# print(h)

# g = {"a": 6, "b": 3, "c": 1, "d":2}
# a = []
# temp = 0
# for keys, values in g.items():
#     if temp > values:
#         values = temp
#         a.append(keys)
#         print(temp)


        # print(f"{key} ==> {val}")
        # if val % 2 == 0:
        #     raise ValueError("Value is even")
        # elif val % 3 == 0:
        #     raise KeyError("Value is divisible by 3")

# =================================================================

# dic ={"a": 1, "b": 2, "c": 3,"d":4,"e":5,"f":6}

# temp= 0

# try:
    
    
#     for key,val in dic.items():
#         if temp > val :
#             temp = val
#         else:
#             print(f"{val} ==> {key}")
#     print(f"Maximum value: {key} => {val}")
    
    
    
    
# except Exception as e:
#     print(e)


# =================================================================

# d ={'a': 1, 'b': 2, 'c': 3, 'd':4,}
# temp ={}

# for key,val in d.items():
#     temp[val]= key
    
# print(d)
# print(temp)




# =================================================================

# d ={'agf' , 'bd', 'c', 'd'}
# temp ={}

# for key in d:
#     temp[key]=len(key)
    
# print(d)
# print(temp)



# =================================================================


# d ={'agf': 2, 'marks' :65 , 'd':8}
# d["marks"]={"maths":39 ,"science":50,}
# d.pop("marks")
# # for i,j in d["marks"].items():
# #     print(f"{i} ==> {j}")
    
    
# print(d)


# =================================================================




# print(list)
# first  = 0
# second  = 0


# for i in list:
#         list.sort()
#         if (i > first ):
#                 second = first
#                 first = i
# print(f"this is the first highest number {first}")
# print(f"this is the second highest number {second}")

        
# =================================================================

# d={"a":1,"b":2,"c":1,"d":5,"e":1,}
# am ={}

# x =int(input("Enter the number you want to pop "))
# for key,value in d.items():
#         if value != x:
#             am[key]=value   
# print(am)



# =================================================================
# d1={"a":1,"b":2,"c":1,"d":5}
# d2 = {"x":1,"y":5,"g":3}
# for ke in d1.keys():
#         if ke in d2:
#               print(ke)


# =================================================================

# dict1 = {'a': 10, 'b': 20, 'c': 30}
# dict2 = {'b': 5, 'm': 15, 'd': 25}
# dc={}
# for k,v in dict1.items():
#         if k in dict2.keys():
#                 dc[k] =  dict2[k] + dict1[k]
#         else:
#                 dict2[k] = v                   
# print(dict2)           

# =================================================================

# list = [1,2,3,4,5,6,7]
# maxe = max(list)
# print(f"this is the highest number {maxe}")
# i = int(input("k th largest number "))
# print(f"this is the second highest number {list[list.index(maxe)-(i-1)]}")
