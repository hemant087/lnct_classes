x= int(input(''' welcome to ---:Apna Bank:--- 
          How may help you Sir/Mam
          press1 to login 
          press2 to create acount
''' ))
bank ={ "sarvagya" : {"pas": 2468, 
                    "balance": 0 ,
                    "loan_amount" : 0},
       "Mayank":{"pas":1234 ,
                   "balance": 0, 
                   "loan":0 }}
def create():
    
    y = input("do you want to register enter y/n ").lower()
    if y == "y" :
        user = input("enter your username ")
        new = input("enter your 4password ")        
        bal = int(input("Add amount to your balance "))        
        lon = int(input("enter your password "))        
        bank[user] = {"pas": new, "balance": 0+bal ,"loan_amount" : 0+lon}
        print(bank)
        return login()
    else:
        print("jaa nahi bana raha thera acount ")
        
def login():
    username = input("enter your user name ")
    if username in bank.keys():
        pas = int(input(" enter your passward "))
        if bank[username]["pas"] in bank[username].values():
            print(" welcome your bank  ")
            print(username)
            print(bank[username])
            
        else:
            print("wrong passward ")
    else:
        print(" username not avaiable ") 
    return upate()
def upate():
    a = input(" do you want to update your details press y/n ").lower()
    if a == "y":
        username = input("enter your user name ")
        if bank[username]["pas"] in bank[username].values():
            print(""" welcome your bank  """)
            new = input(""" enter your 4password 
                        if you want to change and 
                        if not enter the previous password 
                        or the password will be updated """)        
            bal = int(input("Add amount to your balance "))        
            lon = int(input("enter amount of lone you need"))        
            
            bank[username] = {"pas": new, "balance": 0+bal ,"loan_amount" : 0+lon}
            print(bank)                
                 
    else:
        print ("exit")


if (x == 1):
    login()
else:
    create()
# =========================================================
# x= int(input(''' welcome to ---:Apna Bank:--- 
#           How may help you Sir/Mam
#           press1 to login 
#           press2 to create acount
# ''' ))
# bank ={ "sarvagya" : {"pas": 2468, "balance": 0 ,"loan_amount" : 0} ,"mayank":{"pas":1234 , "balance": 0, "loan":0 }}

# print (bank)