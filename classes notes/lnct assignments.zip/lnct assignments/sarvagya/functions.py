# def areas(lengthen,breathe):
#     a = lengthen*breathe
#     return a

# v = int(input('lengthen of the rectangle '))
# x = int(input('breathe of the rectangle '))
# areas = areas(v,x)
# print (areas)
# =================================================================

# def gu():
#     print("to kas hai aap log ")
# gu()

# =================================================================

# def table(x):
#     for i in range(11):
#         print(f"{x} X {i} = {i*x}")
        
# x = int(input("kun table"))
# table= table(x)
# print(table)

# =================================================================
# def prime(x):
#     if x == 0 or x == 1:
#         print(f"{x} is not prime")
#         return
#     for i in range(2, int(x**0.5) + 1):
#         if x % i == 0:
#             print(f"{x} is not prime")
#             return
#     print(f"{x} is prime")

# x = int(input("kun number prime hai  "))
# prime(x)
        
# def primeNum(n):
#     is_prime = True
#     if n == 0 or n == 1:
#         is_prime = False
#     for i in range(2, int(n**0.5) + 1):
#         if n % i == 0:
#             is_prime = False
#             break
#     if is_prime:
#         print("is prime")
#     else:
#         print("is not prime")

# num = int(input("enter the number:"))
# primeNum(num)

# =================================================================


# =================================================================



# =================================================================



# =================================================================



# =================================================================



# =================================================================



# =================================================================



# =================================================================



# =================================================================



# =================================================================








# =================================================================



